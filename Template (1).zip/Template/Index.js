
function select(choice){
    
}

function checkWinner(){
    
}